import { cn } from "@/lib/utils";

export function BrandMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("h-9 w-9", className)} fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden>
      <rect width="40" height="40" rx="11" fill="var(--primary)" />
      <path d="M8 22h5l2.5-7 4 13 3-9 2 3H32" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="20" cy="11.5" r="2.4" fill="var(--accent)" />
    </svg>
  );
}

export function Wordmark({ subtitle = true, dark }: { subtitle?: boolean; dark?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <BrandMark />
      <div className="leading-tight">
        <p className={cn("font-display text-[17px] font-medium", dark ? "text-nav-text" : "text-ink")}>
          CBT <span className="text-accent">FK</span>
        </p>
        {subtitle && <p className={cn("text-[11px]", dark ? "text-nav-muted" : "text-ink-faint")}>Fakultas Kedokteran</p>}
      </div>
    </div>
  );
}
