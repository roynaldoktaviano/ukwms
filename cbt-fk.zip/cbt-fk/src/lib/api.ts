import {
  allUsers,
  attempts as seedAttempts,
  blocks as seedBlocks,
  exams as seedExams,
  periods as seedPeriods,
  questions as seedQuestions,
  students,
} from "./mock-data";
import { sleep } from "./utils";
import type {
  AssignedExam,
  Attempt,
  Block,
  Exam,
  LiveQuestionProgress,
  LiveStudentProgress,
  OptionLabel,
  Period,
  Question,
  ResultSummary,
  Role,
  Student,
  User,
} from "./types";

const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK !== "false";
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "";

// =====================================================================
//  REAL MODE — pemanggil REST generik untuk backend Python.
//  Endpoint yang diharapkan ada di komentar tiap method di bawah.
// =====================================================================
function token(): string | null {
  if (typeof document === "undefined") return null;
  const m = document.cookie.match(/(?:^|; )cbt_token=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : null;
}

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(token() ? { Authorization: `Bearer ${token()}` } : {}),
      ...(init?.headers ?? {}),
    },
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} @ ${path}`);
  return (await res.json()) as T;
}

// =====================================================================
//  MOCK MODE — DB in-memory (mutasi bertahan selama sesi browser).
// =====================================================================
const db = {
  periods: structuredClone(seedPeriods) as Period[],
  blocks: structuredClone(seedBlocks) as Block[],
  questions: structuredClone(seedQuestions) as Question[],
  exams: structuredClone(seedExams) as Exam[],
  attempts: structuredClone(seedAttempts) as Attempt[],
  users: structuredClone(allUsers) as User[],
};

// Shuffle deterministik (per mahasiswa+ujian) supaya urutan soal stabil.
function seededShuffle<T>(arr: T[], seed: string): T[] {
  let h = 2166136261;
  for (const c of seed) h = (h ^ c.charCodeAt(0)) * 16777619;
  const out = [...arr];
  for (let i = out.length - 1; i > 0; i--) {
    h = (h * 48271) % 0x7fffffff;
    const j = h % (i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function blockQuestions(blockId: string) {
  return db.questions.filter((q) => q.blockId === blockId).sort((a, b) => a.nomor - b.nomor);
}

function assignedFor(examId: string, studentId: string): AssignedExam {
  const exam = db.exams.find((e) => e.id === examId)!;
  const student = db.users.find((u) => u.id === studentId) as Student;
  const pool = blockQuestions(exam.blockId);
  const picked = seededShuffle(pool, examId + studentId).slice(0, Math.min(exam.jumlahSoal, pool.length));
  return { exam, student, soal: picked };
}

function scoreAttempt(exam: Exam, a: Attempt) {
  const soal = assignedFor(exam.id, a.studentId).soal;
  let benar = 0;
  let dikerjakan = 0;
  for (const q of soal) {
    const j = a.jawaban[q.id];
    if (j) {
      dikerjakan++;
      if (j === q.jawabanBenar) benar++;
    }
  }
  const total = soal.length || 1;
  return {
    total,
    dikerjakan,
    benar,
    salah: dikerjakan - benar,
    nilai: Math.round((benar / total) * 100),
    persen: Math.round((dikerjakan / total) * 100),
    estimasi: dikerjakan ? Math.round((benar / dikerjakan) * 100) : 0,
  };
}

// --- Simulasi "live": tiap kali monitor diminta, dorong beberapa peserta maju ---
function tickLive(examId: string) {
  const exam = db.exams.find((e) => e.id === examId);
  if (!exam || exam.status !== "ongoing") return;
  for (const a of db.attempts.filter((x) => x.examId === examId && x.status === "in_progress")) {
    const soal = assignedFor(examId, a.studentId).soal;
    const unanswered = soal.filter((q) => !a.jawaban[q.id]);
    if (unanswered.length && Math.random() < 0.55) {
      const q = unanswered[0];
      // 72% jawab benar, sisanya random
      a.jawaban[q.id] = Math.random() < 0.72 ? q.jawabanBenar : (["A", "B", "C", "D", "E"][Math.floor(Math.random() * 5)] as OptionLabel);
    }
    if (a.sisaDetik) a.sisaDetik = Math.max(0, a.sisaDetik - 6 - Math.floor(Math.random() * 8));
  }
}

// =====================================================================
//  PUBLIC API
// =====================================================================
export const api = {
  // ---------------- AUTH ----------------
  // REAL: GET /auth/me  (pakai Bearer token / cookie sesi dari backend)
  async me(): Promise<User | null> {
    if (!USE_MOCK) {
      try {
        return await http<User>("/auth/me");
      } catch {
        return null;
      }
    }
    await sleep(120);
    const uid = typeof document !== "undefined" ? document.cookie.match(/cbt_uid=([^;]+)/)?.[1] : null;
    return uid ? db.users.find((u) => u.id === decodeURIComponent(uid)) ?? null : null;
  },

  // MOCK only — login demo cepat. (Di produksi alur dipegang SSO.)
  async devLogin(userId: string): Promise<User> {
    await sleep(200);
    const u = db.users.find((x) => x.id === userId);
    if (!u) throw new Error("User tidak ditemukan");
    return u;
  },

  // ---------------- PERIODE ----------------
  // REAL: GET /periods · POST /periods · POST /periods/{id}/activate
  async listPeriods(): Promise<Period[]> {
    if (!USE_MOCK) return http("/periods");
    await sleep(150);
    return structuredClone(db.periods);
  },
  async createPeriod(p: Pick<Period, "nama" | "tahun">): Promise<Period> {
    if (!USE_MOCK) return http("/periods", { method: "POST", body: JSON.stringify(p) });
    await sleep(200);
    const period: Period = { id: `p-${Date.now()}`, status: "draft", ...p };
    db.periods.push(period);
    return period;
  },
  async activatePeriod(id: string): Promise<{ semesterBumped: boolean }> {
    if (!USE_MOCK) return http(`/periods/${id}/activate`, { method: "POST" });
    await sleep(300);
    const next = db.periods.find((p) => p.id === id);
    if (!next) throw new Error("Periode tidak ditemukan");
    const current = db.periods.find((p) => p.status === "active");
    // Aktivasi Ganjil -> Genap menambah semester semua mahasiswa +1
    let bumped = false;
    if (current && current.id !== id) {
      current.status = "closed";
      (db.users.filter((u) => u.role === "student") as Student[]).forEach((s) => (s.semester += 1));
      bumped = true;
    }
    next.status = "active";
    next.activatedAt = new Date().toISOString();
    return { semesterBumped: bumped };
  },

  // ---------------- BLOCK ----------------
  // REAL: GET /blocks · GET /blocks/{id} · POST /blocks · PATCH /blocks/{id}
  async listBlocks(): Promise<Block[]> {
    if (!USE_MOCK) return http("/blocks");
    await sleep(150);
    return structuredClone(db.blocks);
  },
  async getBlock(id: string): Promise<Block> {
    if (!USE_MOCK) return http(`/blocks/${id}`);
    await sleep(120);
    return structuredClone(db.blocks.find((b) => b.id === id)!);
  },
  async createBlock(b: Omit<Block, "id" | "jumlahSoal">): Promise<Block> {
    if (!USE_MOCK) return http("/blocks", { method: "POST", body: JSON.stringify(b) });
    await sleep(250);
    const block: Block = { id: `blk-${Date.now()}`, jumlahSoal: 0, ...b };
    db.blocks.push(block);
    return block;
  },

  // ---------------- SOAL ----------------
  // REAL: GET /blocks/{id}/questions · POST /blocks/{id}/questions · PATCH/DELETE /questions/{id}
  //       POST /blocks/{id}/questions/import  (multipart: file excel/word → backend parse + ekstrak gambar)
  async listQuestions(blockId: string): Promise<Question[]> {
    if (!USE_MOCK) return http(`/blocks/${blockId}/questions`);
    await sleep(150);
    return structuredClone(blockQuestions(blockId));
  },
  async bankSoal(): Promise<Question[]> {
    if (!USE_MOCK) return http("/questions");
    await sleep(180);
    return structuredClone(db.questions);
  },
  async createQuestion(blockId: string, q: Omit<Question, "id" | "blockId" | "nomor">): Promise<Question> {
    if (!USE_MOCK) return http(`/blocks/${blockId}/questions`, { method: "POST", body: JSON.stringify(q) });
    await sleep(200);
    const nomor = blockQuestions(blockId).length + 1;
    const created: Question = { id: `q-${Date.now()}`, blockId, nomor, ...q };
    db.questions.push(created);
    const blk = db.blocks.find((b) => b.id === blockId);
    if (blk) blk.jumlahSoal = blockQuestions(blockId).length;
    return created;
  },
  async updateQuestion(id: string, patch: Partial<Question>): Promise<Question> {
    if (!USE_MOCK) return http(`/questions/${id}`, { method: "PATCH", body: JSON.stringify(patch) });
    await sleep(180);
    const idx = db.questions.findIndex((q) => q.id === id);
    db.questions[idx] = { ...db.questions[idx], ...patch };
    return structuredClone(db.questions[idx]);
  },
  async deleteQuestion(id: string): Promise<void> {
    if (!USE_MOCK) return http(`/questions/${id}`, { method: "DELETE" });
    await sleep(150);
    const q = db.questions.find((x) => x.id === id);
    db.questions = db.questions.filter((x) => x.id !== id);
    if (q) {
      const blk = db.blocks.find((b) => b.id === q.blockId);
      if (blk) blk.jumlahSoal = blockQuestions(q.blockId).length;
    }
  },
  // Pratinjau hasil parse file (di mock kita kembalikan contoh; di produksi backend yang parse).
  async importQuestionsPreview(_blockId: string, _file: File): Promise<Omit<Question, "id" | "blockId" | "nomor">[]> {
    if (!USE_MOCK) {
      const fd = new FormData();
      fd.append("file", _file);
      const res = await fetch(`${API_URL}/blocks/${_blockId}/questions/import?preview=1`, {
        method: "POST",
        headers: token() ? { Authorization: `Bearer ${token()}` } : undefined,
        body: fd,
      });
      if (!res.ok) throw new Error("Gagal mengunggah file");
      return res.json();
    }
    await sleep(700);
    return [
      { pertanyaan: "(dari file) Curah jantung (cardiac output) ditentukan oleh stroke volume dan ...?", bidangIlmu: "Fisiologi", jawabanBenar: "A", pilihan: [{ label: "A", teks: "Heart rate" }, { label: "B", teks: "Tekanan vena" }, { label: "C", teks: "Suhu tubuh" }, { label: "D", teks: "pH darah" }, { label: "E", teks: "Hematokrit" }] },
      { pertanyaan: "(dari file) Bunyi jantung S1 dihasilkan oleh penutupan katup ...?", bidangIlmu: "Anatomi", jawabanBenar: "B", pilihan: [{ label: "A", teks: "Semilunar" }, { label: "B", teks: "Atrioventrikular" }, { label: "C", teks: "Aorta" }, { label: "D", teks: "Pulmonal" }, { label: "E", teks: "Eustachian" }] },
    ];
  },

  // ---------------- UJIAN ----------------
  // REAL: GET /exams · GET /exams/{id} · POST /exams · PATCH /exams/{id}
  async listExams(): Promise<Exam[]> {
    if (!USE_MOCK) return http("/exams");
    await sleep(150);
    return structuredClone(db.exams);
  },
  async getExam(id: string): Promise<Exam> {
    if (!USE_MOCK) return http(`/exams/${id}`);
    await sleep(120);
    return structuredClone(db.exams.find((e) => e.id === id)!);
  },
  async createExam(e: Omit<Exam, "id" | "status" | "lihatHasil" | "blockNama">): Promise<Exam> {
    if (!USE_MOCK) return http("/exams", { method: "POST", body: JSON.stringify(e) });
    await sleep(280);
    const blk = db.blocks.find((b) => b.id === e.blockId);
    const created: Exam = { id: `ex-${Date.now()}`, status: "scheduled", lihatHasil: false, blockNama: blk?.nama ?? "", ...e };
    db.exams.push(created);
    return created;
  },
  // Checklist "Lihat Hasil Ujian" → merilis nilai ke mahasiswa
  async setLihatHasil(id: string, value: boolean): Promise<Exam> {
    if (!USE_MOCK) return http(`/exams/${id}`, { method: "PATCH", body: JSON.stringify({ lihatHasil: value }) });
    await sleep(160);
    const e = db.exams.find((x) => x.id === id)!;
    e.lihatHasil = value;
    return structuredClone(e);
  },

  // Soal acak untuk satu mahasiswa
  async assignedExam(examId: string, studentId: string): Promise<AssignedExam> {
    if (!USE_MOCK) return http(`/exams/${examId}/assigned?student=${studentId}`);
    await sleep(220);
    return structuredClone(assignedFor(examId, studentId));
  },

  // ---------------- ATTEMPT ----------------
  // REAL: POST /exams/{id}/start · PUT /exams/{id}/answer · POST /exams/{id}/submit
  async startAttempt(examId: string, studentId: string): Promise<Attempt> {
    if (!USE_MOCK) return http(`/exams/${examId}/start`, { method: "POST", body: JSON.stringify({ studentId }) });
    await sleep(200);
    let a = db.attempts.find((x) => x.examId === examId && x.studentId === studentId);
    const exam = db.exams.find((e) => e.id === examId)!;
    if (!a) {
      a = { examId, studentId, status: "in_progress", jawaban: {}, startedAt: new Date().toISOString(), sisaDetik: exam.durasiMenit * 60 };
      db.attempts.push(a);
    } else if (a.status === "not_started") {
      a.status = "in_progress";
      a.startedAt = new Date().toISOString();
      a.sisaDetik = exam.durasiMenit * 60;
    }
    return structuredClone(a);
  },
  async saveAnswer(examId: string, studentId: string, questionId: string, label: OptionLabel | null): Promise<void> {
    if (!USE_MOCK) {
      await http(`/exams/${examId}/answer`, { method: "PUT", body: JSON.stringify({ studentId, questionId, label }) });
      return;
    }
    await sleep(40);
    const a = db.attempts.find((x) => x.examId === examId && x.studentId === studentId);
    if (!a) return;
    if (label) a.jawaban[questionId] = label;
    else delete a.jawaban[questionId];
  },
  async submitAttempt(examId: string, studentId: string): Promise<void> {
    if (!USE_MOCK) {
      await http(`/exams/${examId}/submit`, { method: "POST", body: JSON.stringify({ studentId }) });
      return;
    }
    await sleep(300);
    const a = db.attempts.find((x) => x.examId === examId && x.studentId === studentId);
    if (a) {
      a.status = "submitted";
      a.submittedAt = new Date().toISOString();
    }
  },

  // ---------------- HASIL (mahasiswa) ----------------
  // REAL: GET /students/{id}/results
  async resultsForStudent(studentId: string): Promise<ResultSummary[]> {
    if (!USE_MOCK) return http(`/students/${studentId}/results`);
    await sleep(180);
    const out: ResultSummary[] = [];
    for (const e of db.exams.filter((x) => x.pesertaIds.includes(studentId))) {
      const a = db.attempts.find((x) => x.examId === e.id && x.studentId === studentId);
      const done = a?.status === "submitted";
      const sc = a ? scoreAttempt(e, a) : null;
      out.push({
        examId: e.id, examNama: e.nama, blockNama: e.blockNama,
        jenisUjian: e.jenisUjian, tipeUjian: e.tipeUjian, tanggal: a?.submittedAt,
        kkm: e.nilaiMinimum, dirilis: e.lihatHasil,
        status: !done ? "Belum Dikerjakan" : e.lihatHasil ? "Sudah Dikerjakan" : "Belum Dirilis",
        nilai: done && e.lihatHasil ? sc!.nilai : undefined,
        lulus: done && e.lihatHasil ? sc!.nilai >= e.nilaiMinimum : undefined,
      });
    }
    return out;
  },

  // ---------------- MONITORING LIVE (admin) ----------------
  // REAL: GET /exams/{id}/live/students · GET /exams/{id}/live/questions
  //       (di produksi sebaiknya pakai WebSocket/SSE; di mock kita poll)
  async liveStudents(examId: string): Promise<LiveStudentProgress[]> {
    if (!USE_MOCK) return http(`/exams/${examId}/live/students`);
    await sleep(120);
    tickLive(examId);
    const exam = db.exams.find((e) => e.id === examId)!;
    return exam.pesertaIds.map((sid) => {
      const s = db.users.find((u) => u.id === sid) as Student;
      const a = db.attempts.find((x) => x.examId === examId && x.studentId === sid);
      const sc = a ? scoreAttempt(exam, a) : { total: exam.jumlahSoal, dikerjakan: 0, benar: 0, salah: 0, persen: 0, estimasi: 0 };
      return {
        studentId: sid, nama: s.nama, nrp: s.nrp,
        status: a?.status ?? "not_started",
        dikerjakan: sc.dikerjakan, total: sc.total, benar: sc.benar, salah: sc.salah,
        persen: sc.persen, estimasiNilai: sc.estimasi, sisaDetik: a?.sisaDetik,
      };
    });
  },
  async liveQuestions(examId: string): Promise<LiveQuestionProgress[]> {
    if (!USE_MOCK) return http(`/exams/${examId}/live/questions`);
    await sleep(120);
    const exam = db.exams.find((e) => e.id === examId)!;
    const soal = blockQuestions(exam.blockId).slice(0, exam.jumlahSoal);
    const sessions = db.attempts.filter((x) => x.examId === examId);
    return soal.map((q) => {
      let benar = 0, salah = 0, belum = 0;
      for (const a of sessions) {
        const j = a.jawaban[q.id];
        if (!j) belum++;
        else if (j === q.jawabanBenar) benar++;
        else salah++;
      }
      return { questionId: q.id, nomor: q.nomor, bidangIlmu: q.bidangIlmu, totalMengerjakan: benar + salah, benar, salah, belum };
    });
  },

  // ---------------- USER (super admin) ----------------
  // REAL: GET /users?role= · POST /users
  async listUsers(role?: Role): Promise<User[]> {
    if (!USE_MOCK) return http(`/users${role ? `?role=${role}` : ""}`);
    await sleep(160);
    return structuredClone(role ? db.users.filter((u) => u.role === role) : db.users);
  },
  async createUser(payload: Partial<User> & { role: Role; password?: string }): Promise<User> {
    if (!USE_MOCK) return http("/users", { method: "POST", body: JSON.stringify(payload) });
    await sleep(240);
    const { password, ...rest } = payload as Record<string, unknown>;
    void password;
    const user = { id: `u-${Date.now()}`, ...(rest as object) } as User;
    db.users.push(user);
    return user;
  },

  // dipakai admin saat memilih peserta ujian (bulk per-semester / per-nama)
  async listStudents(): Promise<Student[]> {
    if (!USE_MOCK) return http("/users?role=student");
    await sleep(120);
    return structuredClone(db.users.filter((u) => u.role === "student") as Student[]);
  },
};

export { students };
